#
# hello.py: Print out greetings in various languages
#

print("hello")
print("G'day")
print("Bula")
print("Kia ora")

