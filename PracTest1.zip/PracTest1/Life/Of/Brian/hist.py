    1  wsl help
    2  sudo apt install wsl
    3  wget ttps://repo.continuum.io/archive/Anaconda3-2019.07-Linux-x86_64.sh
    4  python
    5  wsl --instal
    6  wsl --install
    7  wsl
    8  sudo apt install wsl
    9  dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all /norestart
   10  wsl
   11  wsl --help
   12  git
   13  vml
   14  wml
   15  wget ttps://repo.continuum.io/archive/Anaconda3-2019.07-Linex-x86_64.sh
   16  python3
   17  wml
   18  wget https://repo.continuum.io/archive/Anaconda3-2019.07-Linex-x86_64.sh
   19  wget https://repo.continuum.io/archive/Anaconda3-2019.07-Linex-x86_64.sh --no-check-certificate
   20  wget https://repo.continuum.io/archive/Anaconda3-2019.07-Linex-x86_64.sh
   21  wget https://repo.continuum.io/archive/Anaconda3-2019.07-Linex-x86_64.sh --no-check-certificate
   22  wget https://repo.continuum.io/archive/Anaconda3-2019.07-Linux-x86_64.sh --no-check-certificate
   23  sudo bash Anaconda3-2019.07-Linux-x86_64.sh
   24  which pyhton
   25  which python
   26  python
   27  python3
   28  ls
   29  cd ../
   30  ls
   31  cd vlanducci/
   32  ls
   33  vim test.py
   34  python3 test.py
   35  rm test.py 
   36  ls
   37  cd ../
   38  ls
   39  cd ../
   40  ls
   41  cd home/
   42  ls
   43  cd ../
   44  ls
   45  cd usr/
   46  LS
   47  ls
   48  cd local/
   49  ls
   50  cd src/
   51  ls
   52  cd ../
   53  cd include/
   54  ls
   55  cd ..
   56  ls
   57  cd ..
   58  ls
   59  cd b
   60  cd bin
   61  ls
   62  cd ..
   63  ls
   64  cd usr/
   65  ls
   66  cd lib
   67  ls
   68  cd ..
   69  ls
   70  cd local/
   71  ls
   72  dc lib
   73  cd lib
   74  ls
   75  cd ..
   76  ls
   77  cd scr
   78  cd src
   79  ls
   80  cd ..
   81  cd share/
   82  ls
   83  cd ..
   84  cd include/
   85  ls
   86  cd ..
   87  cd bin/
   88  ls
   89  cd ..
   90  ls
   91  cd local/
   92  ls
   93  cd src/
   94  ls
   95  cd ..
   96  cd include/
   97  LS
   98  ls
   99  cd ..
  100  ls
  101  cd ..
  102  ls
  103  cd home/
  104  ls
  105  cd vlanducci/
  106  cd
  107  ls
  108  vim test.py
  109  ls
  110  ls Anaconda3-2019.07-Linux-x86_64.sh 
  111  cd ..
  112  ls
  113  cd mnt/
  114  ls
  115  cd c/
  116  ls
  117  cd Users/
  118  ls
  119  cd All\ Users
  120  ls
  121  cd D
  122  cd Desktop
  123  ls
  124  cd ..
  125  ls
  126  cd D
  127  cd Desktop
  128  ls
  129  vim test.py
  130  vim test2.py
  131  cd ..
  132  ls
  133  cd Documents
  134  ls
  135  cd My\ 
  136  cd ..
  137  ls
  138  vim test2.py
  139  rm test2.py 
  140  ls
  141  cd L22landv/
  142  ls
  143  cd ..
  144  ls
  145  cd ..
  146  ls
  147  cd L22landv/
  148  ls
  149  cd Documents/
  150  ls
  151  cd ..
  152  ls
  153  cd 'OneDrive - All Saints College'
  154  ls
  155  cd Desktop/
  156  ls
  157  echo -e "Normal \e[5mBlink"
  158  cd FOP/
  159  ls
  160  cd Code/
  161  ls
  162  mkdir Random
  163  ls
  164  cd Random/
  165  mkdir test
  166  ls
  167  vim threadingTest.py
  168  ls
  169  rm test.py 
  170  ls
  171  cd ..
  172  ls
  173  cd vv
  174  cd vlanducci/
  175  ls
  176  cd ..
  177  ls
  178  cd mnt/
  179  ls
  180  cd c/
  181  ls
  182  cd Users/
  183  ls
  184  cd L22
  185  cd L22landv/
  186  ls
  187  cd 'OneDrive - All Saints College'
  188  ls
  189  cd Desktop/
  190  cd FOP/
  191  cd Code/
  192  mkdir Prac03
  193  ls
  194  cd Prac03/
  195  cd ..
  196  cd Random/
  197  vim matplotlib.py
  198  python3 matplotlib.py
  199  vim matplotlib.py
  200  python3 matplotlib.py
  201  ls
  202  cd keyboardTest/
  203  ls
  204  vim keyboardTest.py
  205  python3 keyboardTest.py
  206  vim keyboardTest.py
  207  python3 keyboardTest
  208  cd ..
  209  python3 keyboardTest
  210  cd keyboardTest/
  211  vim keyboardTest.py 
  212  python3 keyboardTest.py 
  213  source ~/.bashrc
  214  which python
  215  echo 'export Display=0.0' >>~/.bashrc
  216  source ~/.bashrc
  217  python3
  218  cd ..
  219  ls
  220  cd Prac03/
  221  ls
  222  python3 newGrowth.py.py 
  223  ls
  224  python3
  225  sudo bash Anaconda3-2019.07-Linux-x86_64.sh 
  226  ls
  227  vim Anaconda3-2019.07-Linux-x86_64.sh 
  228  cd /mnt/c/Users/L22landv/OneDrive - All Saints College/Desktop/FOP
  229  cd /mnt/c/Users/
  230  cd L22landv/OneDrive - All Saints College/Desktop/FOP
  231  cd L22landv/OneDrive - All Saints College/Desktop
  232  cd L22landv/OneDrive - All Saints College/
  233  cd L22landv/
  234  cd OneDrive - All Saints College/
  235  ls
  236  cd 'OneDrive - All Saints College'
  237  cd D
  238  cd Desktop/
  239  cd FOP/
  240  ls
  241  cd Code/
  242  cd Prac03/
  243  cd ..
  244  mkdir Prac01
  245  mkdir Prac0
  246  mv Prac0 Prac2
  247  mkdir Prac3
  248  mkdir Prac4
  249  mkdir Prac5
  250  mkdir Prac6
  251  mkdir Prac7
  252  mkdir Prac8
  253  mkdir Prac9
  254  mkdir Prac10
  255  mkdir Prac11
  256  ls
  257  rm Prac3
  258  rmdir Prac3
  259  mv Prac2 Prac02
  260  ls
  261  mv Prac4 Prac04
  262  mv Prac5 Prac05
  263  mv Prac6 Prac06
  264  mv Prac7 Prac07
  265  mv Prac8 Prac08
  266  mv Prac9 Prac09
  267  ls
  268  cd Prac01
  269  ls
  270  vim README
  271  ls
  272  vim numbers1.py
  273  vim numbers2.py
  274  vim numbers3.py
  275  vim hello.py
  276  vim #
  277  vim growth.py
  278  ls
  279  cd ..
  280  cd Prac02
  281  ls
  282  vim README
  283  vim assorted.py
  284  vim bucket1.py
  285  vim bucket2.py
  286  ls
  287  vim cointoss.py
  288  vim strings1.py
  289  vim strings2.py
  290  # ///////////// second characters with a range loop /////////////
  291  print("Every Second Character is : ", end="")
  292  for index in range (1, len(instring), 2):
  293  print()
  294  print("Every Second Character minus first and last is : ", end="")
  295  for index in range (1, (len(instring)-2), 2):
  296  print("\n")
  297  # ///////////// second characters with slicing /////////////
  298  print('Every Second Character is :', instring[1::2])
  299  # minus first and last
  300  modInstring = instring[1:-1]
  301  print('Every Second Character minus first and last is :', modInstring[::2])
  302  echo 'export DISPLAY=0:0' >> ~/.bashrc
  303  source ~/.bashrc
  304  ls
  305  vim x.java
  306  exit
  307  ls
  308  cd /mnt/c/Users/L22landv/'OneDrive - All Saints College'/Desktop/FOP
  309  ls
  310  cd Code/
  311  ls
  312  cd Prac02
  313  ls
  314  cd Extension/
  315  ls
  316  vim triangleArea.py 
  317  ls
  318  vim triangleArea.py 
  319  ls
  320  vim triangleArea.py 
  321  colorscheme delek
  322  vim triangleArea.py 
  323  wget "https://github.com/rafi/awesome-vim-colorschemes.git"
  324  wget https://github.com/rafi/awesome-vim-colorschemes.git
  325  git
  326  git clone https://github.com/rafi/awesome-vim-colorschemes.git
  327  Plug 'sts10/vim-pink-moon'
  328  curl -O https://raw.githubusercontent.com/sts10/vim-pink-moon/master/colors/pink-moon.vim
  329  vim triangleArea.py 
  330  git clone https://github.com/sts10/vim-pink-moon.git
  331  vim
  332  cd ~/.vim/colors
  333  ls
  334  cd
  335  ls
  336  cd Code/
  337  cd Prac02
  338  cd Extension/
  339  vim triangleArea.py 
  340  cd cd /mnt/c/Users/L22landv/'OneDrive - All Saints College'/Desktop/FOP
  341  cd /mnt/c/Users/
  342  cd cd L22landv/'OneDrive - All Saints College'/Desktop/FOP
  343  cd cd L22landv/
  344  cd /mnt/c/Users/L22landv/'OneDrive - All Saints College'/Desktop/FOP
  345  ls
  346  cd Code/
  347  ls
  348  cd Prac02
  349  ls
  350  mkdir Extension
  351  cd Extension/
  352  ls
  353  vim triangleArea.py
  354  ls
  355  sudo su
  356  source ~/.bashrc
  357  which python
  358  which python3
  359  cd /home/vlanducci/
  360  ls
  361  ls -l
  362  sudo su
  363  ./Anaconda3-2019.07-Linux-x86_64.sh 
  364  ls
  365  source ~/.bashrc
  366  which python
  367  python3
  368  jupyter notebook --no-browser
  369  color 0a
  370  ls
  371  cd FOP/
  372  cd Code/
  373  cd Prac02
  374  cd Extension/
  375  vim triangleArea.py 
  376  python3 triangleArea.py 
  377  vim triangleArea.py 
  378  python3 triangleArea.py 
  379  vim triangleArea.py 
  380  python3 triangleArea.py 
  381  vim triangleArea.py 
  382  python3 triangleArea.py 
  383  vim triangleArea.py 
  384  python3 triangleArea.py 
  385  vim triangleArea.py 
  386  cd ..
  387  ls
  388  vim darts.py
  389  python3 darts.py
  390  cd Extension/
  391  ls
  392  vim bingoCard.py
  393  python3 bingoCard.py
  394  vim diceroll.py
  395  python3 diceroll.py
  396  vim myDiceroll.py
  397  vim playingCards.py
  398  python3 playingCards.py
  399  vim playingCards.py
  400  cd /mnt/c/Users/L22landv/'OneDrive - All Saints College'/Desktop/FOP
  401  cd Code/
  402  cd Prac02
  403  cd Extension/
  404  vim playingCards.py 
  405  vim triangleArea.py 
  406  rm triangleArea.py 
  407  ls
  408  vim triangle.py
  409  ls
  410  vim triangle.py 
  411  cd /mnt/c/Users/L22landv/'OneDrive - All Saints College'/Desktop/FOP
  412  cd Code/
  413  cd Prac02
  414  cd Extension/
  415  ls
  416  vim triangle.py
  417  python3 bingoCard.py 
  418  vim bingoCard.py 
  419  vim bingoCardTest.py 
  420  python3 bingoCardTest.py 
  421  vim bingoCardTest.py 
  422  python3 bingoCardTest.py 
  423  vim bingoCardTest.py 
  424  python3 bingoCardTest.py 
  425  vim bingoCardTest.py 
  426  vim bingoCard.py 
  427  vim bingoCardTest.py 
  428  python3 bingoCardTest.py 
  429  vim bingoCardTest.py 
  430  python3 bingoCardTest.py 
  431  vim bingoCardTest.py 
  432  python3 bingoCardTest.py 
  433  ls
  434  python3 diceroll.py 
  435  python3 myDiceroll.py 
  436  ls
  437  python3 playingCards.py 
  438  vim playingCards.py 
  439  python3 playingCards.py 
  440  ls
  441  vim bingoCardTest.py 
  442  python3 bingoCardTest.py 
  443  vim bingoCardTest.py 
  444  ls
  445  vim bingoCardTest.py 
  446  cd ..
  447  vim README 
  448  cd ..
  449  ls
  450  cd Prac03
  451  ls
  452  vim newGrowth.py.py 
  453  vim newGrowth.py 
  454  rm newGrowth.py.py 
  455  ls
  456  python3 newGrowth.py 
  457  vim newGrowth.py 
  458  python3 newGrowth.py 
  459  vim newGrowth.py 
  460  python3 newGrowth.py 
  461  vim newGrowth.py 
  462  python3 newGrowth.py 
  463  vim newGrowth.py 
  464  python3 newGrowth.py 
  465  vim newGrowth.py 
  466  python3 newGrowth.py 
  467  vim newGrowth.py 
  468  cd FOP/
  469  cd Code/
  470  cd Prac03
  471  ls
  472  vim newGrowth.py 
  473  cd /mnt/c/Users/L22landv/'OneDrive - All Saints College'/Desktop/FOP
  474  ls
  475  cd Code/
  476  cd Prac03
  477  vim newGrowth.py 
  478  python3 newGrowth.py 
  479  vim newGrowth.py 
  480  python3 newGrowth.py 
  481  vim newGrowth.py 
  482  python3 newGrowth.py 
  483  vim newGrowth.py 
  484  python3 newGrowth.py 
  485  vim newGrowth.py 
  486  python3 newGrowth.py 
  487  vim newGrowth.py 
  488  python3 newGrowth.py 
  489  vim newGrowth.py 
  490  python3 newGrowth.py 
  491  vim newGrowth.py 
  492  cd /mnt/c/Users/L22landv/'OneDrive - All Saints College'/Desktop/FOP
  493  cd Code/
  494  cd Prac03
  495  ls
  496  vim README
  497  cd /mnt/c/Users/L22landv/'OneDrive - All Saints College'/Desktop/FOP
  498  cd Code/
  499  cd Prac03
  500  vim newGrowth.py 
  501  ls
  502  python3 numbersarray.py 
  503  ls
  504  vim newGrowth.py 
  505  ls
  506  vim growtharray.py
  507  python3 growtharray.py
  508  vim growtharray.py
  509  python3 growtharray.py
  510  vim growtharray.py
  511  python3 growtharray.py
  512  vim growtharray.py
  513  python3 growtharray.py
  514  vim growtharray.py
  515  python3 growtharray.py
  516  vim growtharray.py
  517  python3 growtharray.py
  518  vim growtharray.py
  519  python3 growtharray.py
  520  vim growtharray.py
  521  python3 growtharray.py
  522  vim growtharray.py
  523  python3 growtharray.py
  524  vim growtharray.py
  525  python3 growtharray.py
  526  vim growtharray.py
  527  cd FOP/
  528  cd Code/
  529  cd Prac03
  530  ls
  531  vim README
  532  cd ..
  533  ls
  534  cd Prac
  535  cd Prac01
  536  ls
  537  vim README 
  538  cd ..
  539  cd Prac03
  540  vim README
  541  vim newGrowth.py 
  542  vim README 
  543  cd ..
  544  cd Prac01
  545  ls
  546  vim numbers2.py 
  547  cd ..
  548  cd Prac03
  549  vim newGrowth.py 
  550  vim numbersarray.py
  551  python3 numbersarray.py 
  552  vim numbersarray.py
  553  python3 numbersarray.py 
  554  vim numbersarray.py
  555  python3 numbersarray.py 
  556  vim numbersarray.py
  557  python3 numbersarray.py 
  558  vim numbersarray.py
  559  python3 numbersarray.py 
  560  vim numbersarray.py
  561  python3 numbersarray.py 
  562  vim numbersarray.py
  563  python3 numbersarray.py 
  564  vim numbersarray.py
  565  python3 numbersarray.py 
  566  vim numbersarray.py
  567  python3 numbersarray.py 
  568  vim numbersarray.py
  569  python3 numbersarray.py 
  570  vim numbersarray.py
  571  python3 numbersarray.py 
  572  vim numbersarray.py
  573  ls
  574  vim newGrowth.py 
  575  vim growtharray.py
  576  ls
  577  vim newGrowth.py.py 
  578  vim newGrowth.py
  579  cd /mnt/c/Users/L22landv/'OneDrive - All Saints College'/Desktop/FOP
  580  ls
  581  cd Code/
  582  ls
  583  mkdir PracTest1
  584  cd PracTest1/
  585  ls
  586  mkdir The
  587  ls
  588  mkdir Life
  589  cd The/
  590  mkdir Meaning
  591  ls
  592  mkdir Holy
  593  cd Meaning/
  594  mkdir Of
  595  cd Of/
  596  mkdir Life
  597  ls
  598  cd ..
  599  ls
  600  cd ..
  601  ls
  602  cd Holy/
  603  ls
  604  mkdir Grail
  605  ls
  606  cd ..
  607  ls
  608  cd ..
  609  ls
  610  cd Life/
  611  mkdir Of
  612  ls
  613  cd Of/
  614  mkdir Brian
  615  ls
  616  cd ..
  617  ls
  618  cd ..
  619  ls
  620  cd ..
  621  ls
  622  cd PracT
  623  cd PracTest1/
  624  cd Life/
  625  cd Of/
  626  cd Brian/
  627  vim test1.py
  628  python3 test1.py
  629  vim test1.py
  630  python3 test1.py
  631  vim test1.py
  632  python3 test1.py
  633  vim test1.py
  634  python3 test1.py
  635  vim test1.py
  636  python3 test1.py
  637  vim test1.py
  638  python3 test1.py
  639  vim test1.py
  640  python3 test1.py
  641  vim test1.py
  642* 
  643  vim test1.py
  644  python3 test1.py
  645  vim test1.py
  646  python3 test1.py
  647  vim test1.py
  648  python3 test1.py
  649  vim test1.py
  650  python3 test1.py
  651  vim test1.py
  652  python3 test1.py
  653  vim test1.py
  654  history>hist.py
  655  ls
  656  vim hist.py 
  657  rm hist.py 
  658  ls
  659  vim hist.py 
  660  history>hist.py
